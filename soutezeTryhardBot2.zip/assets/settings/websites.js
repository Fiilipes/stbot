const websites = {
    "survivalServer": "https://localhost:3000",
    "githubRepository": "https://github.com/Fiilipes/SSProductions-Bot/blob/main"
}

export default websites;