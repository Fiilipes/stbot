const roles = {
    "ateam": "1130870401237536868",
    "unverified": "1130870307717124136",
    "member": "1130870458221351033"
}

export default roles;