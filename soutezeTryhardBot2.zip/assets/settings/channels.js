const channels = {
    "pravidla": "1130870152892776558",
    "atext": "1131374398759243806",
    "history": "1131374722005864539",
    "soutěže": "1130949408989663274",
}

export default channels;