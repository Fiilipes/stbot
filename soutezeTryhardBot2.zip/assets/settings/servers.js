const servers = {
    "survivalServer": {
        "name": "Survival Server",
        "id": "1130282306683277423",
    },
    "soutezeTryhard": {
        "name": "Soutěže Tryhard",
        "id": "1130637842276683909",
    }
}

export default servers;