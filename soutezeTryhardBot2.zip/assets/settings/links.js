import websites from "./websites.js";

const links = {
    "home": `${websites.survivalServer}/`,
}

export default links;