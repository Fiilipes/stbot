const forumTags = {
    "seminář": "1131707602657615904",
    "soustředění": "1131707632084852928",
    "soutěž": "1131707533845860422",
    "olympiáda": "1131707563919020042",
    "registrace": "1131707654180438036",
    "víceDní": "1131707679283368046",
}

export default forumTags;

