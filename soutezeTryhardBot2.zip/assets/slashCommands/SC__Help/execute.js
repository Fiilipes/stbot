const execute = async (interaction) => {
    interaction.reply({content: "Help is on the way!", ephemeral: true});
}

export default execute;